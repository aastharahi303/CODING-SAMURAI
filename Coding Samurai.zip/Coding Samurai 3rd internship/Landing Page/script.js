document.addEventListener("DOMContentLoaded", () => {
    
    document.querySelectorAll("[data-btn]").forEach(button => {
        button.addEventListener("click", () => {
            const action = button.getAttribute("data-btn");
            if (action === "book") {
                alert("Booking process started!");
            } else if (action === "read") {
                alert("Read More clicked!");
            } else if (action === "register") {
                alert("Registration process started!");
            }
        });
    });

    function toggleMenu() {
        alert("Hamburger menu clicked!");
    }

    function toggleSearchBar() {
        alert("Search bar clicked!");
    }

    function togglelogin() {
        alert("Login button clicked!");
    }

    document.querySelector(".hamburger-menu").addEventListener("click", toggleMenu);
    document.querySelector(".search-bar").addEventListener("click", toggleSearchBar);
    document.querySelector(".login-btn").addEventListener("click", togglelogin);
});

document.addEventListener("DOMContentLoaded", function () {
    
    document.querySelector(".play-button").addEventListener("click", function () {
        alert("Company video will play here.");
    });

    
    document.querySelector(".subscribe-button").addEventListener("click", function () {
        let email = document.querySelector(".newsletter input").value.trim();
        if (email === "") {
            alert("Please enter your email.");
        } else if (!validateEmail(email)) {
            alert("Please enter a valid email address.");
        } else {
            alert("Subscribed successfully!");
            document.querySelector(".newsletter input").value = "";
        }
    });

    
    function validateEmail(email) {
        let re = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        return re.test(email);
    }
});

