function changeLanguage(language) {
    if (language === 'hi') {
      // Change text to Hindi
      document.getElementById("welcome-message").innerText = "वापसी पर स्वागत है, अहमद!";
      document.getElementById("login-message").innerText = "कृपया अपना विवरण दर्ज करें।";
      document.getElementById("username-label").innerText = "उपयोगकर्ता नाम";
      document.getElementById("password-label").innerText = "पासवर्ड";
      document.getElementById("remember-label").innerText = "30 दिनों के लिए याद रखें";
      document.getElementById("forgot-password").innerText = "पासवर्ड भूल गए?";
      document.getElementById("login-button").value = "लॉग इन करें";
      document.getElementById("google-login").innerText = "गूगल";
      document.getElementById("facebook-login").innerText = "फेसबुक";
      document.getElementById("signup-message").innerHTML = "खाता नहीं है? <a href='#'>साइन अप</a>";
    } else {
      // Change text to English
      document.getElementById("welcome-message").innerText = "Welcome Back, Ahmad!";
      document.getElementById("login-message").innerText = "Welcome back, please enter your details.";
      document.getElementById("username-label").innerText = "Username";
      document.getElementById("password-label").innerText = "Password";
      document.getElementById("remember-label").innerText = "Remember for 30 days";
      document.getElementById("forgot-password").innerText = "Forgot password?";
      document.getElementById("login-button").value = "Login";
      document.getElementById("google-login").innerText = "Google";
      document.getElementById("facebook-login").innerText = "Facebook";
      document.getElementById("signup-message").innerHTML = "Don't have an account? <a href='#'>Sign up</a>";
    }
  }
  
  function togglePasswordVisibility() {
    var passwordField = document.getElementById("password");
    var toggleIcon = document.querySelector(".toggle-icon");
    if (passwordField.type === "password") {
      passwordField.type = "text";
      toggleIcon.textContent = "🙈";
    } else {
      passwordField.type = "password";
      toggleIcon.textContent = "👁️";
    }
  }
  